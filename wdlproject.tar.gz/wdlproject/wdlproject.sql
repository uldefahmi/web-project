-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Oct 25, 2018 at 11:57 AM
-- Server version: 5.7.23-0ubuntu0.16.04.1
-- PHP Version: 7.0.32-0ubuntu0.16.04.1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `wdlproject`
--

-- --------------------------------------------------------

--
-- Table structure for table `book`
--

CREATE TABLE `book` (
  `isbn` int(10) NOT NULL,
  `title` varchar(40) NOT NULL,
  `author` varchar(20) NOT NULL,
  `edition` varchar(20) NOT NULL,
  `publication` varchar(20) NOT NULL,
  `status` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `book`
--

INSERT INTO `book` (`isbn`, `title`, `author`, `edition`, `publication`, `status`) VALUES
(1, 'Applied Mathematics-IV', 'Kumbojhkar', '3rd Edition', 'Jamnadas', 'Available'),
(2, 'Database Management System', 'G.K. Gupta', '2nd Edition', 'Public', 'Unavailable'),
(3, 'Applied Mathematics-III', 'Kumbojhkar', '2nd Edition', 'Jamnadas', 'Available');

-- --------------------------------------------------------

--
-- Table structure for table `issue`
--

CREATE TABLE `issue` (
  `sid` varchar(8) NOT NULL,
  `username` varchar(25) NOT NULL,
  `book` varchar(30) DEFAULT NULL,
  `issue_date` date DEFAULT NULL,
  `due_date` date DEFAULT NULL,
  `reissue` int(2) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `issue`
--

INSERT INTO `issue` (`sid`, `username`, `book`, `issue_date`, `due_date`, `reissue`) VALUES
('16co11', 'Altamas', 'Applied Mathematics-IV', '2018-10-15', '2018-10-22', 3),
('16co17', 'Fahmi', 'Applied Mathematics-III', '2018-10-25', '2018-11-01', 3);

-- --------------------------------------------------------

--
-- Table structure for table `staffmember`
--

CREATE TABLE `staffmember` (
  `stid` varchar(8) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(14) NOT NULL,
  `cpassword` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `staffmember`
--

INSERT INTO `staffmember` (`stid`, `name`, `email`, `username`, `password`, `cpassword`) VALUES
('1', 'salman shamsi', 'shamsi123@gmail.com', 'salman', '12345678', '12345678'),
('2', 'rehaal qureshi', 'rehaal123@gmail.com', 'rehaal', '12121212', '12121212'),
('3', 'Muhammad Irfan', 'irfan123@gmail.com', 'Irfan', '1212121212', '1212121212');

-- --------------------------------------------------------

--
-- Table structure for table `student`
--

CREATE TABLE `student` (
  `sid` varchar(8) NOT NULL,
  `name` varchar(30) NOT NULL,
  `email` varchar(30) NOT NULL,
  `username` varchar(15) NOT NULL,
  `password` varchar(14) NOT NULL,
  `cpassword` varchar(14) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `student`
--

INSERT INTO `student` (`sid`, `name`, `email`, `username`, `password`, `cpassword`) VALUES
('16co11', 'Shaikh Altamas Shakeel', 'skaltamas123@gmail.com', 'Altamas', 'Altamas123', 'Altamas123'),
('16co14', 'Shaikh Safiya Naaz', 'sksafiya@gmail.com', 'Safiya', '12345678', '12345678'),
('16co15', 'Shaikh Shafaq Naushad', 'shafaq123@gmail.com', 'Shafaq', '1234512345', '1234512345'),
('16co17', 'Ulde Fahmi Nisar', 'fahmiulde@gmail.com', 'Fahmi', '12121212', '12121212');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `book`
--
ALTER TABLE `book`
  ADD PRIMARY KEY (`isbn`);

--
-- Indexes for table `issue`
--
ALTER TABLE `issue`
  ADD PRIMARY KEY (`sid`);

--
-- Indexes for table `staffmember`
--
ALTER TABLE `staffmember`
  ADD PRIMARY KEY (`stid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

--
-- Indexes for table `student`
--
ALTER TABLE `student`
  ADD PRIMARY KEY (`sid`),
  ADD UNIQUE KEY `email` (`email`),
  ADD UNIQUE KEY `username` (`username`);

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
