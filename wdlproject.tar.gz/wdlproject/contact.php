//contact.php
<?php
require_once('php/dbconn.php');
?>
<?php
if ($_POST) {
	$isbn = $_POST['email'];
	$title = $_POST['subject'];
	$author = $_POST['message'];
	
	$sql = "INSERT INTO services (email, subject, message)
VALUES ('$email', '$subject', '$message')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>

<!DOCTYPE html>
<html>
<head>
	<title>Reach Us</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
	<link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
</head>
<body>
	<header>
		<nav>
			<ul>
				<li class="title">Library Management System</br>(LMS)</li>
				
				<li><a href="home.html" title="About us">Home</a></li>

				<li><a href="services.html" title="Services we provide">Services</a></li>
				
				<li><a href="signup.html" title="Create your account">Sign Up</a></li>

				<li><a href="login.html" title="Log in to your account">Log In</a></li>

				<li><a href="contact.html" title="Contact us">Contact</a></li>				
			</ul>
		</nav>
	</header>

	<main>
		<div class="contact-form">
			<h3>Contact Us</h3>
			<form method="post"  action="contact.php">
				<label>
					<div>
						Email
					</div>
					<input type="email" name="user-email" value="" placeholder="username@example.com">
				</label>
				<label>
					<div>
						Subject
					</div>
					<input type="text" name="subject" value="" placeholder="A short description about the matter">
				</label>
				<label>
					<div>
						Message
					</div>
					<textarea name="message" placeholder="Any message to give..."></textarea>
				</label>
				<div>
					<input type="submit" name="submit" value="Submit">		
				</div>
				
			</form>	
		</div>
		
		<div class="social-media">
			<h3>Get Connected</h3>

			<a href="https://facebook.com"><i href="#" class="fa fa-facebook"></i>Facebook</a>

			<a href="https://twitter.com"><i href="#" class="fa fa-twitter"></i>Twitter</a>
			
			<a href="https://linkedin.com"><i href="#" class="fa fa-linkedin"></i>LinkedIn</a>
			
			<a href="https://github.com"><i href="#" class="fa fa-yahoo"></i>Yahoo</a>
			
			<a href="https://stackoverflow.com"><i href="#" class="fa fa-google"></i>Google</a>
		</div>
	</main>
	
	<footer>
		<div>
	
			&copy;2018 All rights reserved - Shaikh Altamas Shakeel & Ulde Fahmi Nisar	
		
		</div>
	</footer>

</body>
</html>
