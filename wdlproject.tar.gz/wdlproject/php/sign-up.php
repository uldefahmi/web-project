<?php

define('DB_HOST', 'localhost');
define('DB_NAME', 'wdlproject');
define('DB_USER','root');
define('DB_PASSWORD',' ');

$con=mysqli_connect(DB_HOST,DB_USER,DB_PASSWORD) or die("Failed to connect to MySQL: " . mysqli_error());
$db=mysqli_select_db(DB_NAME,$con) or die("Failed to connect to MySQL: " . mysqli_error());


function NewUser()
{
	$fullname = $_POST['name'];
	$username = $_POST['user'];
	$email = $_POST['email'];
	$pass =  $_POST['pass'];
	$query = "INSERT INTO users (fullname,username,email,pass) VALUES ('$fullname','$username','$email','$pass')";
	$data = mysqli_query ($query)or die(mysqli_error());
	if($data)
	{
	echo "YOUR REGISTRATION IS COMPLETED...";
	}
}

function SignUp()
{
if(!empty($_POST['user']))   //checking the 'user' name which is from signup.html, is it empty or have some text
{
	$query = mysqli_query("SELECT * FROM users WHERE username = '$_POST['user']' AND pass = '$_POST['pass']'") or die(mysqli_error());

	if(!$row = mysqli_fetch_array($query) or die(mysqli_error()))
	{
		NewUser();
	}
	else
	{
		echo "SORRY...YOU ARE ALREADY REGISTERED USER...";
	}
}
}
if(isset($_POST['submit']))
{
	SignUp();
}
?>