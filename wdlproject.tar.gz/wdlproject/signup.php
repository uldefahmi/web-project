<?php
require_once('php/dbconn.php');
?>
?>
<?php
if ($_POST) {
	$isbn = $_POST['name'];
	$title = $_POST['email'];
	$author = $_POST['username'];
	$edition = $_POST['password'];
	$publication = $_POST['confirmpassword'];

	$sql = "INSERT INTO services (name, email, username,password,confirmpassword)
VALUES ('$name', '$email', '$username','$password','$confirmpassword')";

if ($conn->query($sql) === TRUE) {
    echo "New record created successfully";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

$conn->close();
}
?>
<!DOCTYPE HTML>
<html>

<head>
	<title>Sign-Up</title>
	<link rel="stylesheet" type="text/css" href="css/style.css" />
</head>

<body>
	
	<header>
		<nav>
			<ul>
				<li class="title">Library Management System</br>(LMS)</li>
				
				<li><a href="home.html" title="About us">Home</a></li>

				<li><a href="services.html" title="Services we provide">Services</a></li>
				
				<li><a href="signup.html" title="Create your account">Sign Up</a></li>

				<li><a href="login.html" title="Log in to your account">Log In</a></li>

				<li><a href="contact.html" title="Contact us">Contact</a></li>				
			</ul>
		</nav>
	</header>

	<main>
		<div id="Sign-Up">
			<fieldset style="width:30%"><legend>Registration Form</legend>
				<table border="0">
				
					<tr>
					<form method="post" action="signup.php">
						<td class="name">Name</td><td> <input type="text" name="name"></td>
						</tr>

						<tr>
						<td class="email">Email</td><td> <input type="text" name="email"></td>
						</tr>
						
						<tr>
						<td class="username">UserName</td><td> <input type="text" name="user"></td>
						</tr>

						<tr>
						<td class="password">Password</td><td> <input type="password" name="pass"></td>
						</tr>

						<tr>
						<td class="confirmpassword">Confirm Password </td><td><input type="password" name="cpass"></td>
						</tr>

						<tr>
						<td><input id="button" type="submit" name="submit" value="submit"></td>
						</tr>
					</form>
				</table>
			</fieldset>
		</div>
	</main>

	<footer>
		<div>
	
			&copy;2018 All rights reserved - Shaikh Altamas Shakeel & Ulde Fahmi Nisar	
		
		</div>
	</footer>

</body>

</html>
